/** Automatically generated file. DO NOT MODIFY */
package com.jesstech.bluetoothspp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}