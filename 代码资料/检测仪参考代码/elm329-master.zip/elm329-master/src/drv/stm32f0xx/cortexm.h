#ifndef __CORTEX_M_H__
#define __CORTEX_M_H__

#include <stm32f0xx_adc.h>
#include <stm32f0xx_can.h>
#include <stm32f0xx_tim.h>
#include <stm32f0xx_usart.h>
#include <stm32f0xx_gpio.h>
#include <stm32f0xx_rcc.h>

#endif
